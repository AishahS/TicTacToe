import React from "react";
import Game from "./components/Game";

const App = () => <Game />;

export default App;
